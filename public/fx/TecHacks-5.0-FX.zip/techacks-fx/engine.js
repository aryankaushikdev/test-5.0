// Effects engine. Runs inside a hidden extension iframe (so MediaPipe's
// WebAssembly is never blocked by the call site's security policy).
// Receives camera frames from the page, returns processed frames.
import { FilesetResolver, HandLandmarker, ImageSegmenter } from './lib/vision_bundle.mjs';

// ------------------------------------------------------------------ settings
const settings = {
  enabled: true, snap: true, cash: true,   // cash = both hands up → sticker rain
  debug: false, sensitivity: 'normal',
  bgBlur: false,
  // TecHacks additions
  bgScene: 'orbit',                 // orbit | dusk | mission | studio | blur | off
  badge: true, badgeName: '', badgeRole: 'Hacker', badgeTrack: '',
  countdown: true, launchAt: '2027-01-15T10:00:00+05:30', durationH: 24,
  rainStyle: 'techacks',            // techacks | cash
  shipit: true, hiSign: true,
};
const isBlur = () => settings.bgScene === 'blur' || (settings.bgBlur && settings.bgScene === 'off');
const sceneOn = () => !!sceneBmp && settings.bgScene !== 'blur' && settings.bgScene !== 'off';

// ---------- TecHacks assets: fonts, scenes, stickers
const TH = { mark: null, logo: null, hi: null, rocket: null, head: null, starry: null, emblem: null };
let sceneBmp = null, sceneKey = '';
async function loadImg(path) {
  const img = new Image(); img.src = chrome.runtime.getURL(path); await img.decode(); return createImageBitmap(img);
}
async function loadTH() {
  const fonts = [['Unbounded', 'unbounded-latin-800-normal', 800], ['Unbounded', 'unbounded-latin-900-normal', 900],
    ['JetBrains Mono', 'jetbrains-mono-latin-700-normal', 700], ['JetBrains Mono', 'jetbrains-mono-latin-800-normal', 800],
    ['Space Grotesk', 'space-grotesk-latin-500-normal', 500], ['Space Grotesk', 'space-grotesk-latin-700-normal', 700]];
  for (const [fam, file, wt] of fonts) {
    try { const f = new FontFace(fam, `url(${chrome.runtime.getURL('fonts/' + file + '.woff2')})`, { weight: String(wt) }); await f.load(); document.fonts.add(f); } catch (e) {}
  }
  const list = { mark: 'assets/mark.png', logo: 'assets/logo-cream.png', hi: 'assets/pilot-hi.png', rocket: 'assets/rocket.png',
    head: 'assets/pilot-head.png', starry: 'assets/pilot-starry.png', emblem: 'assets/emblem.png' };
  for (const [k, p] of Object.entries(list)) { try { TH[k] = await loadImg(p); } catch (e) { console.warn('asset failed', p); } }
}
async function loadScene() {
  const k = settings.bgScene;
  if (k === sceneKey) return;
  sceneKey = k; sceneBmp = null;
  if (!['orbit', 'dusk', 'mission', 'studio'].includes(k)) return;
  try { sceneBmp = await loadImg(`backgrounds/${k}.jpg`); } catch (e) { console.warn('scene failed', k); }
}
const SENS = {
  low:    { pinch: 0.38, curl: 0.16 },
  normal: { pinch: 0.46, curl: 0.10 },
  high:   { pinch: 0.56, curl: 0.05 },
};

function post(msg, transfer) {
  window.parent.postMessage(Object.assign({ __thfx: 1 }, msg), '*', transfer || []);
}

// ------------------------------------------------------------------ models
let fileset = null, hand = null, ready = false;
let seg = null, prevMask = null;

async function createTask(Cls, path, opts) {
  let lastErr;
  for (const delegate of ['GPU', 'CPU']) {
    try {
      return await Cls.createFromOptions(fileset, Object.assign({
        baseOptions: { modelAssetPath: chrome.runtime.getURL(path), delegate },
        runningMode: 'VIDEO',
      }, opts));
    } catch (e) { lastErr = e; }
  }
  throw lastErr;
}

async function loadSettings() {
  const s = await chrome.storage.local.get(settings);
  Object.assign(settings, s);
  chrome.storage.onChanged.addListener(async (ch) => {
    for (const k of Object.keys(ch)) if (k in settings) settings[k] = ch[k].newValue;
    if (ch.enabled) post({ type: 'active', value: settings.enabled !== false });
    if (ch.bgScene) await loadScene();
  });
}

async function init() {
  try {
    await loadSettings();
    fileset = await FilesetResolver.forVisionTasks(chrome.runtime.getURL('lib/wasm'));
    hand = await createTask(HandLandmarker, 'models/hand_landmarker.task', {
      numHands: 2, minHandDetectionConfidence: 0.5, minHandPresenceConfidence: 0.5, minTrackingConfidence: 0.5,
    });
    // Dedicated selfie segmenter: a much tighter person cut-out than a pose model's mask,
    // so the real room no longer shows around your head and shoulders.
    seg = await createTask(ImageSegmenter, 'models/selfie_segmenter_landscape.tflite', {
      outputConfidenceMasks: true, outputCategoryMask: false,
    });
    await loadTH();
    buildTechSprites();
    await loadScene();
    ready = true;
    post({ type: 'ready' });
    post({ type: 'active', value: settings.enabled !== false });
  } catch (e) {
    console.error(e);
    post({ type: 'error', message: 'Engine failed to start: ' + (e && e.message || e) });
  }
}

// ------------------------------------------------------------------ canvases
let W = 0, H = 0, MW = 0, MH = 0;
const GW = 128; let GH = 72;
const PW = 160; let PH = 90;
const C = {};
function makeCanvas(name, w, h, opts) {
  const c = new OffscreenCanvas(w, h);
  C[name] = c;
  C[name + 'Ctx'] = c.getContext('2d', opts || {});
  return C[name + 'Ctx'];
}

let maskImg = null, looseImg = null, aliveImg = null, partImg = null, part32 = null, ppImg = null;
let grainPattern = null;
let bgFrames = 0;
let billSprites = [];

function setup(w, h) {
  W = w; H = h;
  const s = Math.min(1, 512 / W);
  MW = Math.max(16, Math.round(W * s)); MH = Math.max(16, Math.round(H * s));
  GH = Math.max(8, Math.round(GW * H / W));
  PH = Math.max(8, Math.round(PW * H / W));

  makeCanvas('out', W, H);
  makeCanvas('ml', MW, MH);
  makeCanvas('bg', W, H);
  makeCanvas('tmp', W, H);
  makeCanvas('tmp2', W, H);
  makeCanvas('plate', W, H);
  makeCanvas('cin', W, H);
  makeCanvas('pp', PW, PH, { willReadFrequently: true });
  makeCanvas('ppOut', PW, PH);
  ppImg = C.ppOutCtx.createImageData(PW, PH);
  makeCanvas('gray', 24, 24, { willReadFrequently: true });
  makeCanvas('alive', GW, GH);
  aliveImg = C.aliveCtx.createImageData(GW, GH);
  aliveImg.data.fill(255);
  setupMask(MW, MH);
  bgFrames = 0;

  const g = makeCanvas('grain', 256, 256);
  const gi = g.createImageData(256, 256);
  for (let i = 0; i < gi.data.length; i += 4) {
    const v = 128 + (Math.random() - 0.5) * 255;
    gi.data[i] = gi.data[i + 1] = gi.data[i + 2] = v; gi.data[i + 3] = 255;
  }
  g.putImageData(gi, 0, 0);
  grainPattern = C.outCtx.createPattern(C.grain, 'repeat');
  if (!billSprites.length) billSprites = [makeBill(['#a9d18e', '#5f8f45']), makeBill(['#b7d9a0', '#6b9a52']), makeBill(['#9cc784', '#557f3d'])];
}

function setupMask(w, h) {
  makeCanvas('mask', w, h);
  makeCanvas('loose', w, h);
  makeCanvas('dmask', w, h);
  makeCanvas('combo', w, h);
  makeCanvas('snap', w, h, { willReadFrequently: true });
  makeCanvas('part', w, h);
  maskImg = C.maskCtx.createImageData(w, h);
  looseImg = C.looseCtx.createImageData(w, h);
  for (const img of [maskImg, looseImg]) {
    img.data.fill(255);
    for (let i = 3; i < img.data.length; i += 4) img.data[i] = 0;
  }
  partImg = C.partCtx.createImageData(w, h);
  part32 = new Uint32Array(partImg.data.buffer);
}

// ------------------------------------------------------------------ person mask
let personFrac = 0, head = null;   // head ≈ top-centre of your silhouette (normalised)

function updateMask(m) {
  const w = m.width, h = m.height;
  if (!C.mask || C.mask.width !== w || C.mask.height !== h) setupMask(w, h);
  const raw = m.getAsFloat32Array();
  // Light temporal smoothing kills edge flicker; it drops fast (so no ghost halo when you
  // move) and rises a little slower (so the room never flashes through).
  if (!prevMask || prevMask.length !== raw.length) prevMask = Float32Array.from(raw);
  const f = prevMask;
  for (let i = 0; i < raw.length; i++) { const p = f[i], v = raw[i]; f[i] = v < p ? p * 0.25 + v * 0.75 : p * 0.45 + v * 0.55; }
  const d = maskImg.data, l = looseImg.data;
  let count = 0, sx = 0, top = h;
  for (let i = 0, j = 3; i < f.length; i++, j += 4) {
    const v = f[i];
    if (v > 0.6) { sx += i % w; const y = (i / w) | 0; if (y < top) top = y; }
    const a = v <= 0.5 ? 0 : v >= 0.8 ? 255 : (v - 0.5) * 850;
    d[j] = a;
    l[j] = v >= 0.12 ? 255 : v * 2125;   // generous version: hair, edges, shadows
    if (a > 127) count++;
  }
  personFrac = count / f.length;
  head = count > 50 ? { x: sx / count / w, y: Math.min(0.9, top / h + 0.14) } : null;
  C.maskCtx.putImageData(maskImg, 0, 0);
  C.looseCtx.putImageData(looseImg, 0, 0);
  if (!C.pm || C.pm.width !== w || C.pm.height !== h) makeCanvas('pm', w, h);
  C.pmCtx.clearRect(0, 0, w, h);
  C.pmCtx.filter = 'blur(0.6px)';
  C.pmCtx.drawImage(C.mask, 0, 0);
  C.pmCtx.filter = 'none';

  // Grown + softened copy used to cut you out of the picture completely.
  const dm = C.dmaskCtx;
  dm.clearRect(0, 0, w, h);
  dm.filter = `blur(${Math.max(3, w / 45)}px)`;
  for (let k = 0; k < 6; k++) dm.drawImage(C.loose, 0, 0);
  dm.filter = 'none';
}

function clearMask() {
  personFrac = 0;
  for (const img of [maskImg, looseImg]) for (let j = 3; j < img.data.length; j += 4) img.data[j] = 0;
  for (const n of ['mask', 'loose', 'dmask']) C[n + 'Ctx'].clearRect(0, 0, C[n].width, C[n].height);
}

// ------------------------------------------------------------------ background plate
// Continuously remembers what is behind you, so when you vanish the room is still there.
function learnBackground(frame) {
  const t = C.tmpCtx;
  t.globalCompositeOperation = 'copy';
  t.drawImage(frame, 0, 0, W, H);
  t.globalCompositeOperation = 'destination-out';
  t.drawImage(C.dmask, 0, 0, W, H);
  t.drawImage(C.dmask, 0, 0, W, H);
  t.globalCompositeOperation = 'source-over';
  C.bgCtx.globalAlpha = bgFrames < 15 ? 0.5 : 0.18;
  C.bgCtx.drawImage(C.tmp, 0, 0);
  C.bgCtx.globalAlpha = 1;
  bgFrames++;
}

// Fills the never-seen area behind you from the surrounding room (push-pull fill),
// so nothing of you leaks into the empty space.
function buildPlate() {
  const ctx = C.ppCtx;
  ctx.globalCompositeOperation = 'copy';
  ctx.drawImage(C.bg, 0, 0, PW, PH);
  const src = ctx.getImageData(0, 0, PW, PH).data;
  let w = PW, h = PH;
  const n0 = w * h;
  let L = { w, h, R: new Float32Array(n0), G: new Float32Array(n0), B: new Float32Array(n0), A: new Float32Array(n0) };
  for (let i = 0; i < n0; i++) {
    const a = src[i * 4 + 3] / 255;
    L.A[i] = a < 0.15 ? 0 : a; L.R[i] = src[i * 4]; L.G[i] = src[i * 4 + 1]; L.B[i] = src[i * 4 + 2];
  }
  const levels = [L];
  while (w > 1 || h > 1) {
    const nw = Math.ceil(w / 2), nh = Math.ceil(h / 2), n = nw * nh;
    const N = { w: nw, h: nh, R: new Float32Array(n), G: new Float32Array(n), B: new Float32Array(n), A: new Float32Array(n) };
    for (let y = 0; y < nh; y++) for (let x = 0; x < nw; x++) {
      let sa = 0, sr = 0, sg = 0, sb = 0;
      for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) {
        const fx = x * 2 + dx, fy = y * 2 + dy;
        if (fx >= w || fy >= h) continue;
        const i = fy * w + fx, a = L.A[i];
        sa += a; sr += L.R[i] * a; sg += L.G[i] * a; sb += L.B[i] * a;
      }
      const o = y * nw + x;
      if (sa > 0) { N.R[o] = sr / sa; N.G[o] = sg / sa; N.B[o] = sb / sa; }
      N.A[o] = Math.min(1, sa);
    }
    levels.push(N); L = N; w = nw; h = nh;
  }
  for (let k = levels.length - 2; k >= 0; k--) {
    const F = levels[k], Co = levels[k + 1];
    for (let y = 0; y < F.h; y++) for (let x = 0; x < F.w; x++) {
      const i = y * F.w + x, ci = (y >> 1) * Co.w + (x >> 1), a = F.A[i];
      F.R[i] = F.R[i] * a + Co.R[ci] * (1 - a);
      F.G[i] = F.G[i] * a + Co.G[ci] * (1 - a);
      F.B[i] = F.B[i] * a + Co.B[ci] * (1 - a);
      F.A[i] = 1;
    }
  }
  const F = levels[0], d = ppImg.data;
  for (let i = 0; i < n0; i++) { d[i * 4] = F.R[i]; d[i * 4 + 1] = F.G[i]; d[i * 4 + 2] = F.B[i]; d[i * 4 + 3] = 255; }
  C.ppOutCtx.putImageData(ppImg, 0, 0);

  const p = C.plateCtx;
  p.globalCompositeOperation = 'copy';
  p.filter = `blur(${Math.round(W / PW * 2)}px)`;
  p.drawImage(C.ppOut, -4, -4, W + 8, H + 8);
  p.filter = 'none';
  p.globalCompositeOperation = 'source-over';
  p.drawImage(C.bg, 0, 0);
  if (isBlur()) {
    p.globalCompositeOperation = 'copy';
    p.filter = `blur(${blurPx()}px)`;
    p.drawImage(C.plate, 0, 0);
    p.filter = 'none';
    p.globalCompositeOperation = 'source-over';
  }
}

const blurPx = () => Math.max(6, Math.round(W / 70));

// Our own background blur. It runs BEFORE the effects, so the sticker rain and
// text stay sharp (Meet's blur runs after us and blurs them).
function drawScene() {
  const o = C.outCtx, sw = sceneBmp.width, sh = sceneBmp.height;
  const s = Math.max(W / sw, H / sh);
  o.drawImage(sceneBmp, (W - sw * s) / 2, (H - sh * s) / 2, sw * s, sh * s);
}

function drawBase(frame) {
  const o = C.outCtx;
  if (sceneOn()) {
    drawScene();
    if (!C.pm) return;
    const t = C.tmpCtx;
    t.globalCompositeOperation = 'copy';
    t.drawImage(frame, 0, 0, W, H);
    t.globalCompositeOperation = 'destination-in';
    t.drawImage(C.pm, 0, 0, W, H);
    t.globalCompositeOperation = 'source-over';
    o.drawImage(C.tmp, 0, 0);
    return;
  }
  if (!isBlur()) { o.drawImage(frame, 0, 0, W, H); return; }
  const pad = blurPx() * 2;
  o.filter = `blur(${blurPx()}px)`;
  o.drawImage(frame, -pad, -pad, W + pad * 2, H + pad * 2);
  o.filter = 'none';
  const t = C.tmpCtx;
  t.globalCompositeOperation = 'copy';
  t.drawImage(frame, 0, 0, W, H);
  t.globalCompositeOperation = 'destination-in';
  t.drawImage(C.loose, 0, 0, W, H);
  t.globalCompositeOperation = 'source-over';
  o.drawImage(C.tmp, 0, 0);
}

function drawPersonRemoved() {
  const t = C.tmp2Ctx;
  t.globalCompositeOperation = 'copy';
  t.drawImage(C.plate, 0, 0);
  t.globalCompositeOperation = 'destination-in';
  t.drawImage(C.dmask, 0, 0, W, H);
  t.globalCompositeOperation = 'source-over';
  C.outCtx.drawImage(C.tmp2, 0, 0);
  C.outCtx.drawImage(C.tmp2, 0, 0); // twice → fully opaque over the soft edge
}

// ------------------------------------------------------------------ noise
function hash(x, y, s) {
  let h = Math.imul(x, 374761393) ^ Math.imul(y, 668265263) ^ Math.imul(s, 982451653);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967295;
}
function vnoise(x, y, s) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash(xi, yi, s), b = hash(xi + 1, yi, s), c = hash(xi, yi + 1, s), d = hash(xi + 1, yi + 1, s);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function fbm(x, y, s) {
  let sum = 0, amp = 0.5, f = 1;
  for (let o = 0; o < 4; o++) { sum += amp * vnoise(x * f, y * f, s + o * 17); f *= 2.1; amp *= 0.5; }
  return sum / 0.9375;
}

// ------------------------------------------------------------------ dust effect
const D_TOTAL = 4.1;   // seconds for a full dissolve
const RETURN_SPEED = 1.5;
let A = null;          // per-cell time at which that part of you turns to dust
let wind = 1;
let np = 0;
let P = null;

function buildDust(frame) {
  wind = Math.random() < 0.5 ? -1 : 1;
  const seed = (Math.random() * 1e6) | 0;
  A = new Float32Array(GW * GH);
  for (let y = 0; y < GH; y++) {
    for (let x = 0; x < GW; x++) {
      const n = fbm(x / GW * 5, y / GW * 8, seed);
      const sweep = wind > 0 ? x / GW : 1 - x / GW;
      const v = Math.min(1, Math.max(0, 0.6 * n + 0.45 * sweep - 0.05));
      A[y * GW + x] = 0.1 + 2.1 * v;
    }
  }

  const mw = C.mask.width, mh = C.mask.height;
  C.snapCtx.drawImage(frame, 0, 0, mw, mh);
  const px = C.snapCtx.getImageData(0, 0, mw, mh).data;
  const md = maskImg.data;
  let candidates = 0;
  for (let j = 3; j < md.length; j += 4) if (md[j] > 140) candidates++;
  const MAXP = 60000;
  const keep = Math.min(1, MAXP / Math.max(1, candidates));

  P = {
    x: new Float32Array(MAXP), y: new Float32Array(MAXP),
    vx: new Float32Array(MAXP), vy: new Float32Array(MAXP),
    act: new Float32Array(MAXP), life: new Float32Array(MAXP), ph: new Float32Array(MAXP),
    r: new Uint8Array(MAXP), g: new Uint8Array(MAXP), b: new Uint8Array(MAXP), big: new Uint8Array(MAXP),
  };
  const sc = mw / 512;
  np = 0;
  for (let y = 0; y < mh && np < MAXP; y++) {
    for (let x = 0; x < mw && np < MAXP; x++) {
      const i = y * mw + x;
      if (md[i * 4 + 3] <= 140 || Math.random() > keep) continue;
      const gx = Math.min(GW - 1, (x / mw * GW) | 0), gy = Math.min(GH - 1, (y / mh * GH) | 0);
      P.x[np] = x; P.y[np] = y;
      P.r[np] = px[i * 4]; P.g[np] = px[i * 4 + 1]; P.b[np] = px[i * 4 + 2];
      P.act[np] = A[gy * GW + gx] + (Math.random() - 0.5) * 0.06;
      P.vx[np] = wind * (20 + 75 * Math.random()) * sc;
      P.vy[np] = -(4 + 38 * Math.random()) * sc;
      P.life[np] = 1.1 + 0.9 * Math.random();
      P.ph[np] = Math.random() * 6.283;
      P.big[np] = Math.random() < 0.12 ? 1 : 0;
      np++;
    }
  }
}

function drawAlivePerson(frame, f) {
  // Parts of you whose time hasn't come yet stay solid (and live).
  const d = aliveImg.data;
  for (let i = 0, j = 3; i < A.length; i++, j += 4) {
    const a = (A[i] - f) * 14;
    d[j] = a <= 0 ? 0 : a >= 1 ? 255 : a * 255;
  }
  C.aliveCtx.putImageData(aliveImg, 0, 0);
  const mw = C.mask.width, mh = C.mask.height;
  const c = C.comboCtx;
  c.globalCompositeOperation = 'copy';
  c.drawImage(C.loose, 0, 0);
  c.globalCompositeOperation = 'destination-in';
  c.drawImage(C.alive, 0, 0, mw, mh);
  c.globalCompositeOperation = 'source-over';

  const t = C.tmpCtx;
  t.globalCompositeOperation = 'copy';
  t.drawImage(frame, 0, 0, W, H);
  t.globalCompositeOperation = 'destination-in';
  t.drawImage(C.combo, 0, 0, W, H);
  t.globalCompositeOperation = 'source-over';
  C.outCtx.drawImage(C.tmp, 0, 0);
}

function drawDust(f) {
  if (!P) return;
  const mw = C.mask.width, mh = C.mask.height;
  part32.fill(0);
  const sc = mw / 512;
  const ax = wind * 55 * sc, ay = -22 * sc, turb = 9 * sc;
  for (let i = 0; i < np; i++) {
    const g = f - P.act[i];
    const life = P.life[i];
    if (g <= 0 || g >= life) continue;
    const g2 = g * g;
    const ph = P.ph[i];
    const x = P.x[i] + P.vx[i] * g + 0.5 * ax * g2 + Math.sin(ph + g * 4.2) * turb * g;
    const y = P.y[i] + P.vy[i] * g + 0.5 * ay * g2 + Math.cos(ph * 1.7 + g * 3.1) * turb * 0.7 * g;
    const xi = x | 0, yi = y | 0;
    if (xi < 0 || yi < 0 || xi >= mw - 1 || yi >= mh - 1) continue;
    const t = g / life;
    const alpha = (255 * Math.pow(1 - t, 1.25)) | 0;
    const k = Math.min(1, t * 2.2);
    const r = (P.r[i] + (66 - P.r[i]) * k) | 0;
    const gg = (P.g[i] + (58 - P.g[i]) * k) | 0;
    const b = (P.b[i] + (52 - P.b[i]) * k) | 0;
    const col = ((alpha << 24) | (b << 16) | (gg << 8) | r) >>> 0;
    const o = yi * mw + xi;
    part32[o] = col;
    if (P.big[i]) { part32[o + 1] = col; part32[o + mw] = col; part32[o + mw + 1] = col; }
  }
  C.partCtx.putImageData(partImg, 0, 0);
  C.outCtx.imageSmoothingEnabled = true;
  C.outCtx.drawImage(C.part, 0, 0, W, H);
}

// ------------------------------------------------------------------ cash rain
function makeBill(tint) {
  const w = 300, h = 128;
  const c = new OffscreenCanvas(w, h);
  const g = c.getContext('2d');
  const grd = g.createLinearGradient(0, 0, w, h);
  grd.addColorStop(0, tint[0]); grd.addColorStop(1, tint[1]);
  g.fillStyle = grd;
  g.beginPath(); g.roundRect(0, 0, w, h, 6); g.fill();
  g.strokeStyle = 'rgba(25,70,25,0.85)'; g.lineWidth = 4; g.strokeRect(9, 9, w - 18, h - 18);
  g.lineWidth = 1.2; g.strokeRect(16, 16, w - 32, h - 32);
  g.strokeStyle = 'rgba(25,70,25,0.18)';
  for (let i = 0; i < 14; i++) { g.beginPath(); g.ellipse(w / 2, h / 2, 34 + i * 8, 20 + i * 3.4, 0, 0, Math.PI * 2); g.stroke(); }
  g.fillStyle = 'rgba(238,246,228,0.95)';
  g.beginPath(); g.ellipse(w / 2, h / 2, 36, 44, 0, 0, Math.PI * 2); g.fill();
  g.strokeStyle = 'rgba(25,70,25,0.9)'; g.lineWidth = 2; g.stroke();
  g.fillStyle = '#1e4d1e';
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = '700 58px Georgia, serif';
  g.fillText('$', w / 2, h / 2 + 3);
  g.font = '700 24px Georgia, serif';
  g.fillText('100', 44, 34); g.fillText('100', w - 44, 34);
  g.fillText('100', 44, h - 32); g.fillText('100', w - 44, h - 32);
  return c;
}

let bills = [];
let cashSpawnUntil = 0, spawnAcc = 0;
function startCash(now) { cashSpawnUntil = now + 3400; }

let techSprites = [];
function holoStar(size, cols) {
  const c = new OffscreenCanvas(size, size), g = c.getContext('2d'), r = size / 2;
  const grd = g.createLinearGradient(0, 0, size, size);
  cols.forEach((col, i) => grd.addColorStop(i / (cols.length - 1), col));
  g.fillStyle = grd; g.beginPath();
  for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4 - Math.PI / 2, rr = i % 2 ? r * 0.32 : r * 0.96; g.lineTo(r + Math.cos(a) * rr, r + Math.sin(a) * rr); }
  g.closePath(); g.fill(); return c;
}
function buildTechSprites() {
  techSprites = [TH.head, TH.starry, TH.emblem, TH.mark, TH.head].filter(Boolean);
  techSprites.push(holoStar(160, ['#5EE7FF', '#B57CFF', '#FFD66B']), holoStar(160, ['#FFD66B', '#FF8A5C', '#FF5B1F']), holoStar(120, ['#E7B3A3', '#3D7BFF']));
}

function spawnBill() {
  const tech = settings.rainStyle !== 'cash' && techSprites.length;
  if (tech) {
    const sp = techSprites[(Math.random() * techSprites.length) | 0];
    const w = W * (0.055 + 0.055 * Math.random());
    bills.push({ x: Math.random() * W, y: -w - Math.random() * H * 0.15, w, vy: H * (0.22 + 0.22 * Math.random()), sway: W * (0.03 + 0.08 * Math.random()),
      sf: 1.2 + 1.6 * Math.random(), ph: Math.random() * 6.28, rot: (Math.random() - 0.5) * 0.8, vr: (Math.random() - 0.5) * 1.6, flip: 0, t: 0, sprite: sp, sticker: true });
    return;
  }
  const w = W * (0.1 + 0.07 * Math.random());
  bills.push({
    x: Math.random() * W, y: -w * 0.6 - Math.random() * H * 0.15, w,
    vy: H * (0.2 + 0.2 * Math.random()), sway: W * (0.05 + 0.12 * Math.random()),
    sf: 1.5 + 2 * Math.random(), ph: Math.random() * 6.28,
    rot: Math.random() * 6.28, vr: (Math.random() - 0.5) * 2.6,
    flip: 2.5 + 4 * Math.random(), t: 0,
    sprite: billSprites[(Math.random() * billSprites.length) | 0],
  });
}

function updateCash(now, dt) {
  if (now < cashSpawnUntil) {
    spawnAcc += dt * 30;
    while (spawnAcc >= 1) { spawnAcc -= 1; spawnBill(); }
  }
  for (const b of bills) {
    b.t += dt;
    b.y += b.vy * dt;
    b.x += Math.sin(b.t * b.sf + b.ph) * b.sway * dt;
    b.rot += b.vr * dt;
  }
  bills = bills.filter((b) => b.y < H + b.w);
}

function drawCash() {
  const o = C.outCtx;
  for (const b of bills) {
    if (b.sticker) {
      const h = b.w * b.sprite.height / b.sprite.width;
      o.save(); o.translate(b.x, b.y); o.rotate(b.rot);
      o.shadowColor = 'rgba(0,0,0,0.35)'; o.shadowBlur = b.w * 0.08; o.shadowOffsetY = b.w * 0.04;
      o.drawImage(b.sprite, -b.w / 2, -h / 2, b.w, h);
      o.restore();
      continue;
    }
    const fl = Math.cos(b.t * b.flip + b.ph);
    const sy = Math.sign(fl || 1) * Math.max(0.12, Math.abs(fl));
    const h = b.w * 128 / 300;
    o.save();
    o.translate(b.x, b.y);
    o.rotate(b.rot);
    o.scale(1, sy);
    o.shadowColor = 'rgba(0,0,0,0.35)'; o.shadowBlur = b.w * 0.06; o.shadowOffsetY = b.w * 0.03;
    o.drawImage(b.sprite, -b.w / 2, -h / 2, b.w, h);
    o.shadowColor = 'transparent';
    if (fl < 0) { o.fillStyle = 'rgba(0,30,0,0.2)'; o.fillRect(-b.w / 2, -h / 2, b.w, h); }
    o.restore();
  }
}

// ------------------------------------------------------------------ state
let state = 'visible'; // visible | dissolving | gone | returning
let tStart = 0;
let lastSnapT = -1e9;
let snapNow = false;
let lastAudioSpike = -1e9;

function onSnapEvent(now) {
  snapNow = true;   // a single snap vanishes you instantly (no waiting for a double snap)
}

function startSnap(frame, now) {
  if (settings.snap === false) return;
  if (now - lastSnapT < 1200) return;
  if (state === 'visible') {
    buildDust(frame);
    state = 'dissolving'; tStart = now; lastSnapT = now;
  } else if (state === 'gone') {
    buildDust(frame);
    state = 'returning'; tStart = now; lastSnapT = now;
  }
}

function effectTime(now) {
  const el = (now - tStart) / 1000;
  if (state === 'dissolving') return el;
  if (state === 'returning') return D_TOTAL - el * RETURN_SPEED;
  return D_TOTAL;
}

function advanceState(now) {
  const el = (now - tStart) / 1000;
  if (state === 'dissolving' && el >= D_TOTAL) { state = 'gone'; P = null; }
  if (state === 'returning' && el * RETURN_SPEED >= D_TOTAL) { state = 'visible'; P = null; A = null; }
}

// ------------------------------------------------------------------ gestures
const handState = {};
const dbg = { hands: [], snapInfo: '', rainInfo: '' };

function lmDist(lm, a, b) {
  const dx = (lm[a].x - lm[b].x) * W, dy = (lm[a].y - lm[b].y) * H;
  return Math.hypot(dx, dy);
}

function detectSnap(hr, now) {
  const sens = SENS[settings.sensitivity] || SENS.normal;
  let fired = false;
  dbg.hands = hr.landmarks || [];
  const infos = [];
  const seen = new Set();
  (hr.landmarks || []).forEach((lm, i) => {
    const label = (hr.handedness && hr.handedness[i] && hr.handedness[i][0] && hr.handedness[i][0].categoryName) || String(i);
    seen.add(label);
    const hs = handState[label] || (handState[label] = { frames: 0, lastPinch: -1e9, d12: 0, lastSeen: now });
    hs.lastSeen = now;
    const sc = lmDist(lm, 0, 9);
    if (sc < 4) return;
    const dTM = lmDist(lm, 4, 12) / sc;   // thumb tip ↔ middle tip
    const d12w = lmDist(lm, 12, 0) / sc;  // middle tip ↔ wrist
    infos.push(`${label[0]} tm=${dTM.toFixed(2)} mw=${d12w.toFixed(2)}${hs.frames >= 2 ? ' armed' : ''}`);

    if (dTM < sens.pinch) {
      hs.frames++; hs.lastPinch = now; hs.d12 = d12w;
    } else {
      const recent = now - hs.lastPinch < 380;
      const released = dTM > sens.pinch + 0.22;
      const curled = d12w < hs.d12 - sens.curl;
      const heard = now - lastAudioSpike < 350;
      if (hs.frames >= 2 && recent && released && (curled || heard)) {
        fired = true; hs.frames = 0;
      }
      if (!recent) hs.frames = 0;
    }
  });
  for (const [label, hs] of Object.entries(handState)) {
    if (!seen.has(label) && hs.frames >= 2 && now - hs.lastPinch < 500 && now - lastAudioSpike < 350) {
      fired = true; hs.frames = 0;
    }
    if (now - hs.lastSeen > 2000) delete handState[label];
  }
  dbg.snapInfo = infos.join('  |  ');
  return fired;
}

// ---- both hands up (open palms, held briefly) → sticker rain
function handsUpByHands(hr) {
  const L = hr.landmarks || [];
  if (L.length < 2) return false;
  const ok = L.map((lm) => {
    const sc = lmDist(lm, 0, 9);
    if (sc < 4) return null;
    const open = [8, 12, 16, 20].filter((t) => lmDist(lm, t, 0) > lmDist(lm, t - 2, 0) * 1.08).length >= 3;
    const upright = (lm[12].y - lm[0].y) * H < -0.9 * sc;
    const high = lm[0].y < 0.85;
    return open && upright && high ? lm[0].x : null;
  });
  if (ok[0] === null || ok[1] === null) return false;
  return Math.abs(ok[0] - ok[1]) > 0.32;
}

let rainSince = 0, rainAt = -1e9;
function updateHandsRain(hr, now) {
  const cond = settings.cash !== false && state === 'visible' && handsUpByHands(hr);
  dbg.rainInfo = cond ? 'hands up!' : '';
  if (!cond) { rainSince = 0; return false; }
  if (!rainSince) rainSince = now;
  if (now - rainSince > 300 && now - rainAt > 3800) { rainAt = now; rainSince = 0; return true; }
  return false;
}

function easeOutBack(t) { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); }

// ------------------------------------------------------------------ TecHacks gestures
// 👍 thumbs up (hold) → the Pilot's rocket launches across the frame + SHIPPED ✓ stamp
// ✌️ peace sign (hold) → the Pilot pops up next to you and says hi
const gest = { ship: { since: 0, at: -1e9 }, hi: { since: 0, at: -1e9 } };
let shipT = -1e9, hiT = -1e9, hiSide = 1, trail = [];
let keyShip = false, keyHi = false;
const ext = (lm, t) => lmDist(lm, t, 0) > lmDist(lm, t - 2, 0) * 1.12;
const curl = (lm, t) => lmDist(lm, t, 0) < lmDist(lm, t - 2, 0) * 1.04;

function isThumbsUp(lm) {
  const sc = lmDist(lm, 0, 9); if (sc < 4) return false;
  if (![8, 12, 16, 20].every((t) => curl(lm, t))) return false;
  const up = (lm[2].y - lm[4].y) * H > 0.85 * sc;
  return up && lm[4].y < lm[6].y && lmDist(lm, 4, 0) > lmDist(lm, 3, 0) * 1.04;
}
function isPeace(lm) {
  const sc = lmDist(lm, 0, 9); if (sc < 4) return false;
  return ext(lm, 8) && ext(lm, 12) && curl(lm, 16) && curl(lm, 20) && lmDist(lm, 8, 12) > 0.3 * sc && lm[8].y < lm[5].y && lm[12].y < lm[9].y;
}
function holdGesture(g, cond, now) {
  if (!cond) { g.since = 0; return false; }
  if (!g.since) g.since = now;
  if (now - g.since > 450 && now - g.at > 3200) { g.at = now; g.since = 0; return true; }
  return false;
}
function updateTHGestures(hr, now, busy) {
  const L = busy ? [] : (hr.landmarks || []);
  const thumbs = settings.shipit !== false && L.some(isThumbsUp);
  const peace = settings.hiSign !== false && L.some(isPeace);
  if (holdGesture(gest.ship, thumbs, now) || keyShip) { keyShip = false; shipT = now; trail = []; }
  if (holdGesture(gest.hi, peace, now) || keyHi) {
    keyHi = false; hiT = now;
    const nose = head;
    hiSide = nose && nose.x > 0.5 ? -1 : 1;
  }
  dbg.thInfo = (thumbs ? '👍 ' : '') + (peace ? '✌️' : '');
}

const easeIO = (t) => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
function stamp(o, text, x, y, size, rot, alpha, scale) {
  o.save(); o.globalAlpha = alpha; o.translate(x, y); o.rotate(rot); o.scale(scale, scale);
  o.font = `900 ${size}px Unbounded, "Arial Black", sans-serif`;
  try { o.letterSpacing = `${Math.round(size * 0.04)}px`; } catch (_) {}
  const tw = o.measureText(text).width, pw = tw + size * 1.1, ph = size * 1.55;
  o.shadowColor = 'rgba(0,0,0,0.35)'; o.shadowBlur = size * 0.5; o.shadowOffsetY = size * 0.15;
  o.fillStyle = 'rgba(255,253,247,0.94)';
  o.beginPath(); o.roundRect(-pw / 2, -ph / 2, pw, ph, size * 0.28); o.fill();
  o.shadowColor = 'transparent';
  o.lineWidth = size * 0.13; o.strokeStyle = '#D7263D'; o.stroke();
  o.fillStyle = '#D7263D'; o.textAlign = 'center'; o.textBaseline = 'middle';
  o.fillText(text, 0, size * 0.04);
  o.restore();
}
function drawShipIt(now) {
  const el = (now - shipT) / 1000;
  if (el < 0 || el > 2.9 || !TH.rocket) return;
  const o = C.outCtx;
  const p = easeIO(Math.min(1, el / 1.7));
  const x = -0.1 * W + 1.2 * W * p, y = 1.08 * H - 1.25 * H * p - Math.sin(p * Math.PI) * 0.06 * H;
  if (el < 1.75) trail.push({ x, y, t: now });
  trail = trail.filter((q) => now - q.t < 700);
  for (const q of trail) {
    const a = 1 - (now - q.t) / 700;
    o.globalAlpha = a * 0.85;
    o.fillStyle = a > 0.6 ? '#FFD66B' : '#FF8A5C';
    o.beginPath(); o.arc(q.x + (Math.random() - 0.5) * H * 0.01, q.y + (Math.random() - 0.5) * H * 0.01, H * 0.018 * a + 1, 0, Math.PI * 2); o.fill();
  }
  o.globalAlpha = 1;
  if (el < 1.75) {
    const rh = H * 0.34, rw = rh * TH.rocket.width / TH.rocket.height;
    o.save(); o.translate(x, y); o.rotate(Math.atan2(-1.25 * H, 1.2 * W) + Math.PI / 2);
    o.drawImage(TH.rocket, -rw / 2, -rh / 2, rw, rh); o.restore();
  }
  const st = el - 0.45;
  if (st > 0) {
    const pop = Math.min(1, st / 0.35), fade = el > 2.5 ? Math.max(0, 1 - (el - 2.5) / 0.4) : 1;
    stamp(o, 'SHIPPED ✓', W / 2, H * 0.6, Math.round(H * 0.075), -0.14, fade, 1.5 - 0.5 * easeOutBack(pop));
  }
}
function drawHi(now) {
  const el = (now - hiT) / 1000;
  if (el < 0 || el > 2.9 || !TH.hi) return;
  const o = C.outCtx;
  const nose = head;
  const cx = Math.min(W * 0.8, Math.max(W * 0.2, (nose ? nose.x * W : W / 2) + hiSide * W * 0.26));
  const cy = Math.min(H * 0.62, Math.max(H * 0.46, (nose ? nose.y * H : H * 0.45) + H * 0.04));
  const pop = Math.min(1, el / 0.45), fade = el > 2.5 ? Math.max(0, 1 - (el - 2.5) / 0.4) : 1;
  const sz = H * 0.36 * easeOutBack(pop);
  o.save(); o.globalAlpha = fade; o.translate(cx, cy); o.rotate(Math.sin(el * 7) * 0.08 * (1 - Math.min(1, el / 1.4)));
  o.shadowColor = 'rgba(0,0,0,0.35)'; o.shadowBlur = H * 0.03; o.shadowOffsetY = H * 0.012;
  o.drawImage(TH.hi, -sz / 2, -sz / 2, sz, sz * TH.hi.height / TH.hi.width);
  o.restore();
  if (el > 0.25) {
    const fs = Math.round(H * 0.045), t = Math.min(1, (el - 0.25) / 0.3);
    o.save(); o.globalAlpha = fade * t;
    o.font = `900 ${fs}px Unbounded, "Arial Black", sans-serif`;
    const tw = o.measureText('HI, CREW!').width, bw = tw + fs * 1.2, bh = fs * 1.7;
    const bx = cx - bw / 2, by = cy - H * 0.2 - bh;
    o.fillStyle = '#F4EEE1'; o.shadowColor = 'rgba(0,0,0,0.3)'; o.shadowBlur = fs * 0.4;
    o.beginPath(); o.roundRect(bx, by, bw, bh, bh / 2); o.fill();
    o.beginPath(); o.moveTo(cx - fs * 0.4, by + bh - 1); o.lineTo(cx + fs * 0.1, by + bh + fs * 0.6); o.lineTo(cx + fs * 0.5, by + bh - 1); o.fill();
    o.shadowColor = 'transparent'; o.fillStyle = '#0A0E1A'; o.textAlign = 'center'; o.textBaseline = 'middle';
    o.fillText('HI, CREW!', cx, by + bh / 2 + fs * 0.04);
    o.restore();
  }
}

// ------------------------------------------------------------------ TecHacks overlays
// Kept inside the middle 76% of the width so Meet's tile cropping never cuts them,
// and lifted above the spot where Meet shows your name.
const pad2 = (n) => String(n).padStart(2, '0');
function countdownText() {
  const launch = Date.parse(settings.launchAt) || Date.parse('2027-01-15T10:00:00+05:30');
  const end = launch + (Number(settings.durationH) || 24) * 3600e3, now = Date.now();
  const hms = (ms) => { const s = Math.floor(ms / 1000); return `${pad2(Math.floor(s / 3600))}:${pad2(Math.floor(s / 60) % 60)}:${pad2(s % 60)}`; };
  if (now < launch) {
    const ms = launch - now;
    if (ms > 86400e3) return { t: `T-${Math.ceil(ms / 86400e3)} DAYS · TECHACKS 5.0`, live: false };
    return { t: `T-${hms(ms)} · LIFT-OFF`, live: false };
  }
  if (now < end) return { t: `LIVE · T+${hms(now - launch)}`, live: true };
  return { t: 'SPLASHDOWN · SEE YOU IN S06', live: false };
}
// Overlays hug the frame edges with a small, even margin.
const edgeM = () => Math.round(Math.min(W, H) * 0.035);
function drawCountdown() {
  const o = C.outCtx, { t, live } = countdownText();
  const fs = Math.max(11, Math.round(H * 0.026)), h = fs * 2.3, x = edgeM(), y = edgeM();
  o.save();
  o.font = `800 ${fs}px "JetBrains Mono", monospace`;
  try { o.letterSpacing = `${Math.round(fs * 0.12)}px`; } catch (_) {}
  const icon = h * 0.7, tw = o.measureText(t).width, w = tw + icon + fs * 2.6;
  o.fillStyle = 'rgba(10,14,26,0.74)';
  o.beginPath(); o.roundRect(x, y, w, h, h / 2); o.fill();
  o.lineWidth = Math.max(1, fs * 0.08); o.strokeStyle = 'rgba(244,238,225,0.22)'; o.stroke();
  if (TH.mark) o.drawImage(TH.mark, x + h * 0.15, y + h * 0.15, icon, icon);
  const pulse = 0.55 + 0.45 * Math.sin(performance.now() / 260);
  o.fillStyle = live ? `rgba(229,72,77,${pulse})` : '#FF5B1F';
  o.beginPath(); o.arc(x + icon + h * 0.4, y + h / 2, fs * 0.28, 0, Math.PI * 2); o.fill();
  o.fillStyle = '#F4EEE1'; o.textBaseline = 'middle';
  o.fillText(t, x + icon + h * 0.4 + fs * 0.7, y + h / 2 + fs * 0.05);
  o.restore();
}
function drawBadge() {
  const name = (settings.badgeName || '').trim();
  if (!name) return;
  const o = C.outCtx;
  const role = [settings.badgeRole, settings.badgeTrack].map((v) => (v || '').trim()).filter(Boolean).join(' · ').toUpperCase();
  const fn = Math.max(14, Math.round(H * 0.046)), fr = Math.max(10, Math.round(H * 0.022));
  o.save();
  o.font = `800 ${fn}px Unbounded, "Arial Black", sans-serif`;
  const nw = o.measureText(name).width;
  o.font = `700 ${fr}px "JetBrains Mono", monospace`;
  try { o.letterSpacing = `${Math.round(fr * 0.14)}px`; } catch (_) {}
  const rw = role ? o.measureText(role).width : 0;
  const ic = fn * 2.05, padX = fn * 0.55, h = fn * 2.65, w = Math.min(W * 0.72, ic + padX * 3 + Math.max(nw, rw));
  const x = edgeM(), y = H - edgeM() - h;
  o.shadowColor = 'rgba(0,0,0,0.35)'; o.shadowBlur = fn * 0.5;
  o.fillStyle = 'rgba(10,14,26,0.80)';
  o.beginPath(); o.roundRect(x, y, w, h, fn * 0.45); o.fill();
  o.shadowColor = 'transparent';
  const hg = o.createLinearGradient(x, 0, x + w, 0);
  ['#5EE7FF', '#B57CFF', '#E7B3A3', '#FFD66B', '#3D7BFF'].forEach((c, i) => hg.addColorStop(i / 4, c));
  o.fillStyle = hg;
  o.beginPath(); o.roundRect(x, y, w, Math.max(3, fn * 0.12), [fn * 0.45, fn * 0.45, 0, 0]); o.fill();
  if (TH.mark) o.drawImage(TH.mark, x + padX, y + (h - ic) / 2, ic, ic);
  const tx = x + padX * 2 + ic;
  o.fillStyle = '#F4EEE1'; o.textBaseline = 'alphabetic';
  o.font = `800 ${fn}px Unbounded, "Arial Black", sans-serif`;
  try { o.letterSpacing = '0px'; } catch (_) {}
  o.fillText(name, tx, y + h * (role ? 0.5 : 0.62), w - (tx - x) - padX);
  if (role) {
    o.font = `700 ${fr}px "JetBrains Mono", monospace`;
    try { o.letterSpacing = `${Math.round(fr * 0.14)}px`; } catch (_) {}
    o.fillStyle = '#FF8A5C';
    o.fillText(role, tx, y + h * 0.78, w - (tx - x) - padX);
  }
  o.restore();
}

// ------------------------------------------------------------------ debug HUD
function drawDebug(fps) {
  const o = C.outCtx;
  o.save();
  o.fillStyle = '#00e5ff';
  for (const lm of dbg.hands) {
    for (const p of lm) o.fillRect(p.x * W - 3, p.y * H - 3, 6, 6);
    o.fillStyle = '#ff3d71';
    for (const k of [4, 12]) o.fillRect(lm[k].x * W - 6, lm[k].y * H - 6, 12, 12);
    o.fillStyle = '#00e5ff';
  }
  const fs = Math.max(12, Math.round(H * 0.028));
  o.font = `600 ${fs}px monospace`;
  o.textAlign = 'left';
  const lines = [
    `state: ${state}   fps: ${fps.toFixed(0)}   person: ${(personFrac * 100).toFixed(0)}%   bg: ${Math.min(100, bgFrames)}`,
    dbg.snapInfo || 'no hands',
    `${dbg.rainInfo || ''} ${dbg.thInfo || ''}`,
  ];
  o.fillStyle = 'rgba(0,0,0,0.55)';
  o.fillRect(8, 8, W * 0.75, lines.length * fs * 1.4 + 10);
  o.fillStyle = '#fff';
  lines.forEach((l, i) => o.fillText(l, 16, 10 + fs * 1.2 * (i + 1)));
  o.restore();
}

// ------------------------------------------------------------------ frame loop
let lastTs = 0, lastT = performance.now(), frameNo = 0, fps = 30;
let keySnap = false, keyCash = false;

function processFrame(id, bmp) {
  const now = performance.now();
  const dt = Math.min(0.1, (now - lastT) / 1000);
  lastT = now;
  fps = fps * 0.9 + (dt > 0 ? 1 / dt : 30) * 0.1;
  frameNo++;

  if (!ready || settings.enabled === false) {
    post({ type: 'result', id, bitmap: bmp }, [bmp]);
    return;
  }
  if (bmp.width !== W || bmp.height !== H) {
    setup(bmp.width, bmp.height);
  }

  C.mlCtx.drawImage(bmp, 0, 0, MW, MH);
  const ts = Math.max(now, lastTs + 1);
  lastTs = ts;

  const hr = hand.detectForVideo(C.ml, ts);

  if (state !== 'visible' || frameNo % 2 === 0 || bgFrames < 15 || isBlur() || sceneOn()) {
    const sr = seg.segmentForVideo(C.ml, ts);
    const masks = sr.confidenceMasks || [];
    if (masks.length) updateMask(masks[masks.length - 1]); else clearMask();
    masks.forEach((m) => m.close && m.close());
    learnBackground(bmp);
  }

  if (detectSnap(hr, now)) onSnapEvent(now);
  if (keySnap) { keySnap = false; snapNow = true; }
  if (keyCash) { keyCash = false; startCash(now); }
  if (snapNow) { snapNow = false; startSnap(bmp, now); }

  const handsUp = updateHandsRain(hr, now);
  if (handsUp) startCash(now);
  updateTHGestures(hr, now, state !== 'visible' || !!dbg.rainInfo);
  advanceState(now);
  updateCash(now, dt);

  const thAnim = now - shipT < 2900 || now - hiT < 2900;
  const overlays = settings.countdown !== false || (settings.badge !== false && (settings.badgeName || '').trim());
  const active = state !== 'visible' || bills.length || settings.debug || isBlur() || sceneOn() || thAnim || overlays;
  if (!active) {
    post({ type: 'result', id, bitmap: bmp }, [bmp]);
    return;
  }

  const o = C.outCtx;
  o.setTransform(1, 0, 0, 1, 0, 0);
  o.globalAlpha = 1;
  o.globalCompositeOperation = 'source-over';
  drawBase(bmp);

  if (state !== 'visible') {
    if (sceneOn()) drawScene();           // vanish into the TecHacks background
    else { buildPlate(); drawPersonRemoved(); }
    if (state === 'dissolving' || state === 'returning') {
      const f = effectTime(now);
      drawAlivePerson(bmp, f);
      drawDust(f);
    }
  }
  if (bills.length) drawCash();
  if (settings.countdown !== false) drawCountdown();
  if (settings.badge !== false) drawBadge();
  drawShipIt(now);
  drawHi(now);
  if (settings.debug) drawDebug(fps);

  bmp.close();
  const res = C.out.transferToImageBitmap();
  post({ type: 'result', id, bitmap: res }, [res]);
}

let errCount = 0;
window.addEventListener('message', (e) => {
  if (e.source !== window.parent) return;
  const d = e.data;
  if (!d || d.__thfx !== 1) return;
  if (d.type === 'frame') {
    try {
      processFrame(d.id, d.bitmap);
    } catch (err) {
      if (errCount++ < 5) console.error('[TecHacks FX]', err);
      try { post({ type: 'result', id: d.id, bitmap: d.bitmap }, [d.bitmap]); }
      catch (_) { post({ type: 'result', id: d.id }); }
    }
  } else if (d.type === 'key') {
    if (d.action === 'snap') keySnap = true;
    if (d.action === 'cash') keyCash = true;
    if (d.action === 'shipit') keyShip = true;
    if (d.action === 'hi') keyHi = true;
    if (d.action === 'scene') {
      const order = ['orbit', 'dusk', 'mission', 'studio', 'blur', 'off'];
      chrome.storage.local.set({ bgScene: order[(order.indexOf(settings.bgScene) + 1) % order.length] });
    }
  } else if (d.type === 'audioSpike') {
    lastAudioSpike = performance.now();
  }
});

init();

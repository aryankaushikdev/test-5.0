# TecHacks 5.0 FX: Chrome extension for Google Meet

This extension puts TecHacks Season 5 on your camera.

- **The background is applied automatically** in Google Meet, with no green screen. You can choose from four TecHacks scenes, blur or your own room.
- Everyone on the call sees the effects. Your own self-view is un-mirrored, so the logo and text read the right way round for you too.

It also works in other browser video calls (Zoom web, Teams web, Discord web).

## Install (2 minutes)
1. Unzip `TecHacks-5.0-FX.zip` somewhere permanent, for example `Documents\techacks-fx`. Don't delete the folder after installing.
2. Open `chrome://extensions` in Chrome (or Edge, Brave or Arc).
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and pick the unzipped `techacks-fx` folder, the one that contains `manifest.json`.
5. Pin the extension (puzzle-piece icon → pin). The TecHacks **5** icon opens the settings.
6. Reload any Meet tab that was already open.
7. If you also installed *Snap & Cinema FX*, turn it off.

## First call
1. In Meet, open **Apply visual effects** and choose **No effect**. Meet's own background runs *after* ours and would cover it.
2. Click the TecHacks icon:
   - Pick a background.
   - Type your name for the **crew badge** and choose your role and track.
3. Join. The background, badge and countdown are already on.

## Backgrounds
| Scene | Look |
|---|---|
| **Orbit** (default) | Night sky, orbit rings, logo top right, season and techacks.tech bottom right |
| **Launchpad** | Dusk gradient, clouds and the rocket lifting off, "From Bharat to World" |
| **Mission control** | HUD grid, holo ring and the Pilot, "channel open" telemetry line |
| **File room** | Bright cream "classified file" desk with the launch card. The most flattering in dim rooms |
| **Blur** | Your room, softly blurred (use this instead of Meet's blur) |
| **My room** | No background change |

Everything sits inside the 4:3 safe area, so Meet's tile cropping never cuts the logo or text.

## TecHacks features
- **Crew badge (bottom-left corner):** your name, role and track, with the 5 mark and holo stripe, close to the edge of the frame.
- **Launch countdown (top-left corner):**
  - Before launch: "T-75 DAYS". In the final day: a live T- clock.
  - During the 24 hours: "LIVE · T+05:12:33".
  - Afterwards: "SPLASHDOWN".
  - The lift-off time can be changed in the popup. It defaults to 15 Jan 2027, 10:00 IST until the official start time is confirmed.
- **👍 Thumbs up (hold ½ s):** the Pilot's rocket launches across your video with a "SHIPPED ✓" stamp.
- **✌️ Peace sign (hold ½ s):** the Pilot pops up next to you with "HI, CREW!".
- **🙌 Both hands up (open palms):** TecHacks sticker rain (Pilot faces, emblems, 5 marks, holo stars). Switch to the original cash rain in the popup if you prefer.

## Kept from Snap & Cinema FX
- **Snap:** you turn to dust into the TecHacks background. Snap again to come back.

Absolute Cinema and the facepalm meme were removed in v1.2 to keep Meet fast. They needed two extra AI models, which slowed Meet's start-up and made video laggy.

## Keyboard shortcuts (click the call tab first)
Press <kbd>Alt</kbd>+<kbd>Shift</kbd> plus:

| Key | Action |
|---|---|
| **B** | Next background |
| **T** | Ship it |
| **H** | Hi, crew |
| **S** | Snap |
| **M** | Sticker rain |

## Good to know
- **Privacy:** everything runs on your computer. The MediaPipe models are bundled, and no video leaves your machine except through the call itself. The mic is only analysed locally to hear a finger snap.
- **Performance:** it uses your GPU. If video stutters on an older laptop, close heavy tabs or pick **My room**, which needs the least processing.
- **Turning effects off:** the master switch applies the next time the camera starts. Toggle your camera or reload the tab.
- **Edges:** v1.1 uses a dedicated selfie-segmentation model, so the real room no longer shows around your head and shoulders. Even, front-facing light gives the cleanest edge; strong backlight (a window behind you) is the hardest case.
- **Self-view:** Google Meet shows you a mirrored copy of your camera. The extension flips that self-view back while it's running, so your badge and the background read correctly for you too. Everyone else always sees it the right way round. Turn this off with **Fix backwards self-view** in the popup.

Made for TecHacks 5.0 · 15–16 January 2027 · Chitkara University · techacks.tech · #TecHacks5
Built on Snap & Cinema FX (MediaPipe Tasks Vision and the MediaPipe selfie segmentation model, Apache 2.0).

const DEFAULTS = {
  enabled: true, snap: true, cash: true, unmirror: true,
  bgBlur: false, debug: false, sensitivity: 'normal',
  bgScene: 'orbit', badge: true, badgeName: '', badgeRole: 'Hacker', badgeTrack: '',
  countdown: true, launchAt: '2027-01-15T10:00:00+05:30', rainStyle: 'techacks', shipit: true, hiSign: true,
};
const $ = (id) => document.getElementById(id);
const set = (o) => chrome.storage.local.set(o);

// launchAt is stored with the IST offset; the picker shows it as IST wall-clock time.
const toLocalInput = (iso) => (iso || '').slice(0, 16);
const fromLocalInput = (v) => (v ? `${v}:00+05:30` : DEFAULTS.launchAt);

function markScene(k) {
  for (const b of document.querySelectorAll('.scene')) b.classList.toggle('sel', b.dataset.scene === k);
}

chrome.storage.local.get(DEFAULTS, (s) => {
  for (const k of ['enabled', 'snap', 'cash', 'unmirror', 'debug', 'badge', 'countdown', 'shipit', 'hiSign']) {
    $(k).checked = !!s[k];
    $(k).addEventListener('change', () => {
      set({ [k]: $(k).checked });
      if (k === 'enabled') $('rejoin').style.display = 'block';
    });
  }
  for (const k of ['sensitivity', 'rainStyle', 'badgeRole', 'badgeTrack']) {
    $(k).value = s[k];
    $(k).addEventListener('change', () => set({ [k]: $(k).value }));
  }
  $('badgeName').value = s.badgeName || '';
  $('badgeName').addEventListener('input', () => set({ badgeName: $('badgeName').value }));
  $('launchAt').value = toLocalInput(s.launchAt);
  $('launchAt').addEventListener('change', () => set({ launchAt: fromLocalInput($('launchAt').value) }));
  markScene(s.bgScene);
  for (const b of document.querySelectorAll('.scene')) {
    b.addEventListener('click', () => { set({ bgScene: b.dataset.scene, bgBlur: false }); markScene(b.dataset.scene); });
  }
});

